<?php 
require '../main.php';
header("location: $exit");
?>