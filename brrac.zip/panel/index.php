<?php 
header("location: settings.php");
?>